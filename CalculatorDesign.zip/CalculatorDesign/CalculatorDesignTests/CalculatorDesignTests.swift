//
//  CalculatorDesignTests.swift
//  CalculatorDesignTests
//
//  Created by user285806 on 11/9/25.
//

import Testing
@testable import CalculatorDesign

struct CalculatorDesignTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
